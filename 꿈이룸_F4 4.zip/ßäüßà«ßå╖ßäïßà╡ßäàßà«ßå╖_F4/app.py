from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# 이미지 업로드 경로 설정
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# 허용된 확장자 설정
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# 임시 데이터 저장소
users = []
questions = []

BACKUP_FILE_PATH = os.path.join(app.instance_path, 'backup.txt')

def ensure_backup_file_exists():
    if not os.path.exists(BACKUP_FILE_PATH):
        os.makedirs(os.path.dirname(BACKUP_FILE_PATH), exist_ok=True)
        with open(BACKUP_FILE_PATH, 'w', encoding='utf-8') as f:
            f.write("")

def ensure_upload_folder_exists():
    absolute_upload_folder = os.path.join(app.root_path, UPLOAD_FOLDER)
    if not os.path.exists(absolute_upload_folder):
        os.makedirs(absolute_upload_folder)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_data():
    ensure_backup_file_exists()
    ensure_upload_folder_exists()  # 업로드 폴더가 있는지 확인하고 생성
    if os.path.exists(BACKUP_FILE_PATH):
        with open(BACKUP_FILE_PATH, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            current_section = None
            current_question = None

            for line in lines:
                line = line.strip()
                if line == "Users:":
                    current_section = "users"
                elif line == "Questions:":
                    current_section = "questions"
                elif line.startswith("Name:"):
                    if current_section == "users":
                        parts = line.split(", ")
                        if len(parts) == 3:
                            name = parts[0].split(": ")[1]
                            student_number = parts[1].split(": ")[1]
                            password_hash = parts[2].split(": ")[1]
                            if not any(user['name'] == name and user['student_number'] == student_number for user in users):
                                users.append({'name': name, 'student_number': student_number, 'password_hash': password_hash})
                elif line.startswith("Title:"):
                    if current_section == "questions":
                        parts = line.split(", ")
                        if len(parts) >= 5:
                            title = parts[0].split(": ")[1]
                            question_text = parts[1].split(": ")[1]
                            category = parts[2].split(": ")[1]
                            author = parts[3].split(": ")[1]
                            image_path = parts[4].split(": ")[1] if len(parts) > 4 else None
                            current_question = {'title': title, 'question': question_text, 'category': category, 'author': author, 'image_path': image_path, 'answers': []}
                            questions.append(current_question)
                elif line.startswith("  Author:") and current_question:
                    parts = line.split(", ")
                    if len(parts) >= 2:
                        answer_author = parts[0].split(": ")[1]
                        answer_text = parts[1].split(": ")[1]
                        answer_image_path = parts[2].split(": ")[1] if len(parts) > 2 else None
                        current_question['answers'].append({'author': answer_author, 'answer': answer_text, 'image_path': answer_image_path})

def backup_data():
    ensure_backup_file_exists()
    with open(BACKUP_FILE_PATH, 'w', encoding='utf-8') as f:
        f.write("Users:\n")
        for user in users:
            f.write(f"Name: {user['name']}, Student Number: {user['student_number']}, Password Hash: {user['password_hash']}\n")
       
        f.write("\nQuestions:\n")
        for question in questions:
            f.write(f"Title: {question['title']}, Question: {question['question']}, Category: {question['category']}, Author: {question['author']}, Image Path: {question.get('image_path', '')}\n")
            f.write("Answers:\n")
            for answer in question['answers']:
                f.write(f"  Author: {answer['author']}, Answer: {answer['answer']}, Image Path: {answer.get('image_path', '')}\n")
            f.write("\n")
    print("Backup complete.")


@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form['name']
        student_number = request.form['student_number']
        password = request.form['password']
        
        # 사용자 인증 로직
        user = next((user for user in users if user['name'] == name and user['student_number'] == student_number), None)
        
        if user and check_password_hash(user['password_hash'], password):
            session['user_name'] = user['name']
            session['logged_in'] = True
            return redirect(url_for('qa'))
        else:
            # 플래시 메시지 설정
            if user:
                flash("비밀번호가 틀렸습니다. 다시 시도하세요.", 'error')
            else:
                flash("회원 가입이 되지 않았습니다.", 'not_registered')
            return redirect(url_for('login'))
            
    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        student_number = request.form['student_number']
        password = request.form['password']

        valid_ranges = [
            (1, 10),
            (10101, 10800),
            (20101, 20800),
            (30101, 30830)
        ]
       
        try:
            student_number_int = int(student_number)
            if not any(start <= student_number_int <= end for start, end in valid_ranges):
                error_message = "학번이 유효하지 않습니다. 유효한 학번을 입력해 주세요."
                return render_template('signup.html', error_message=error_message)
        except ValueError:
            error_message = "학번은 숫자여야 합니다."
            return render_template('signup.html', error_message=error_message)

        existing_user = next((user for user in users if user['student_number'] == student_number), None)
        if existing_user is None:
            password_hash = generate_password_hash(password, method='pbkdf2:sha256')
            users.append({'name': name, 'student_number': student_number, 'password_hash': password_hash})
            backup_data()
            return redirect(url_for('login'))
        else:
            error_message = "해당 학번으로 이미 가입된 사용자가 있습니다. 로그인해 주세요."
            return render_template('signup.html', error_message=error_message)
    
    return render_template('signup.html')

@app.route('/qa')
def qa():
    category = request.args.get('category', 'all')
    if category == 'all':
        filtered_questions = questions
    else:
        filtered_questions = [q for q in questions if q['category'] == category]
    return render_template('qa.html', questions=filtered_questions, category=category)

@app.route('/ask', methods=['GET', 'POST'])
def ask():
    if 'logged_in' in session and session['logged_in']:
        if request.method == 'POST':
            title = request.form['title']
            question = request.form['question']
            category = request.form['category']
            author = session['user_name']
            image_path = None

            # 이미지 업로드 처리
            if 'image' in request.files:
                file = request.files['image']
                if file and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    absolute_image_path = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'], filename)
                    file.save(absolute_image_path)
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

            questions.append({'title': title, 'question': question, 'author': author, 'category': category, 'image_path': image_path, 'answers': []})
            backup_data()
            return redirect(url_for('qa'))
        return render_template('ask.html')
    else:
        flash("로그인 후 질문을 작성할 수 있습니다.", 'error')
        return redirect(url_for('login'))

@app.route('/question/<int:index>', methods=['GET', 'POST'])
def question_detail(index):
    question = questions[index]
    if request.method == 'POST':
        answer = request.form['answer']
        author = session.get('user_name')
        image_path = None
        
        if not author:
            flash("로그인 후 답변을 작성할 수 있습니다.")
            return redirect(url_for('login'))

        # 답변 이미지 업로드 처리
        if 'answer_image' in request.files:
            file = request.files['answer_image']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                absolute_image_path = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'], filename)
                file.save(absolute_image_path)
                image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        question['answers'].append({'author': author, 'answer': answer, 'image_path': image_path})
        backup_data()

        return redirect(url_for
('question_detail', index=index))
    return render_template('question_detail.html', question=question, index=index)

@app.route('/answer_question/<int:index>', methods=['POST'])
def answer_question(index):
    if 'logged_in' in session and session['logged_in']:
        answer = request.form['answer']
        author = session['user_name']
        questions[index]['answers'].append({'author': author, 'answer': answer})
        backup_data()
        return redirect(url_for('question_detail', index=index))
    else:
        flash("로그인 후 답변을 작성할 수 있습니다.", 'error')
        return redirect(url_for('login'))

@app.route('/edit_question/<int:index>', methods=['GET', 'POST'])
def edit_question(index):
    question = questions[index]
    
    if 'user_name' not in session or question['author'] != session['user_name']:
        flash("이 질문을 수정할 권한이 없습니다.")
        return redirect(url_for('qa'))

    if request.method == 'POST':
        question['title'] = request.form['title']
        question['question'] = request.form['question']
        question['category'] = request.form['category']
        flash("질문이 수정되었습니다.")
        backup_data()  # 수정 후 데이터 백업
        return redirect(url_for('qa'))

    return render_template('ask.html', question=question, index=index)

@app.route('/delete_question/<int:index>', methods=['POST'])
def delete_question(index):
    question = questions[index]

    if 'user_name' not in session or question['author'] != session['user_name']:
        flash("이 질문을 삭제할 권한이 없습니다.")
        return redirect(url_for('qa'))

    del questions[index]
    flash("질문이 삭제되었습니다.")
    backup_data()  # 삭제 후 데이터 백업
    return redirect(url_for('qa'))

@app.route('/logout')
def logout():
    session.pop('user_name', None)
    session.pop('logged_in', None)
    flash("로그아웃 되었습니다.", 'info')
    return redirect(url_for('login'))

# 오류 핸들러 추가
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__ == '__main__':
    ensure_upload_folder_exists()  # 서버 시작 시 업로드 폴더가 있는지 확인
    ensure_backup_file_exists()
    load_data()  # 서버 시작 시 데이터 로드
    app.run(debug=True)
